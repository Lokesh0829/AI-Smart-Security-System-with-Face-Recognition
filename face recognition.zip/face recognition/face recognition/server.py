

import cv2
import urllib.request
import numpy as np
import face_recognition
import os
import requests
import time

# ESP32 URL
url = "YOUR_IP"

# Telegram
BOT_TOKEN = ""
CHAT_ID = ""

# Load known faces
known_encodings = []
known_names = []

dataset_path = "dataset"

for file in os.listdir(dataset_path):
    img = face_recognition.load_image_file(f"{dataset_path}/{file}")
    encoding = face_recognition.face_encodings(img)[0]

    known_encodings.append(encoding)
    known_names.append(file.split(".")[0])

print("Loaded known faces:", known_names)

# Telegram function
def send_telegram(frame):
    url_telegram = f"https://api.telegram.org/bot{BOT_TOKEN}/sendPhoto"

    _, buffer = cv2.imencode('.jpg', frame)

    files = {
        'photo': ('image.jpg', buffer.tobytes(), 'image/jpeg')
    }

    data = {
        'chat_id': CHAT_ID
    }

    requests.post(url_telegram, files=files, data=data)

# spam control
last_sent = 0

while True:
    try:
        img_resp = urllib.request.urlopen(url, timeout=5)
        img_np = np.array(bytearray(img_resp.read()), dtype=np.uint8)
        frame = cv2.imdecode(img_np, cv2.IMREAD_COLOR)

        if frame is None:
            continue

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        face_locations = face_recognition.face_locations(rgb)
        face_encodings = face_recognition.face_encodings(rgb, face_locations)

        for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):

            matches = face_recognition.compare_faces(known_encodings, face_encoding)
            name = "Unknown"

            if True in matches:
                index = matches.index(True)
                name = known_names[index]

            # Draw box
            cv2.rectangle(frame, (left, top), (right, bottom), (0,255,0), 2)
            cv2.putText(frame, name, (left, top-10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,255,0), 2)

            # 🚨 Alert only if unknown
            if name == "Unknown":
                if time.time() - last_sent > 10:
                    print("Unknown person detected!")
                    send_telegram(frame)
                    last_sent = time.time()

        cv2.imshow("Face Recognition", frame)

    except Exception as e:
        print("Error:", e)

    time.sleep(0.3)

    if cv2.waitKey(1) == 27:
        break

cv2.destroyAllWindows()